import TabsFull from "@quarkly/community-kit/TabsFull";
export default TabsFull;