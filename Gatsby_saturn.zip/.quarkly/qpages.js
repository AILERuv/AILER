module.exports = [
	"/index/",
	"/404/",
	"/",
	"/404.html"
]